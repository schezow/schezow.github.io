// ===================================================================
// 시스템 설정
// ===================================================================
try{
   DEBUG_CONTENT = true;
   REFRESH_INTERAVAL_MS = 500;
   BLINK_INTERVAL_MS = 550;

   uri = "https://etk.srail.kr/hpg/hbt/06/selectBtLoginInfo.do";

   srt_auto = false;
   blink_val = false;
   blink_enabled=false;
} catch(e) {
   console.log( 'error1', e );
}

// ===================================================================
// 시스템 설정 끝
// ===================================================================


// ========================================================================================
// Log함수
// ========================================================================================
function log( ...p_msg )
{
   if( DEBUG_CONTENT ) {
      console.log( p_msg );
   }
}
// ========================================================================================
// 역명칭을 역코드로 변환
// ========================================================================================
function convertCode( p_region )
{
   var ref = [ '공주', '광주송정', '김천(구미)', '나주', '대전', '동대구', '동탄', '목포', '부산', '수서', '신경주', '오송', '울산(통도사)', '익산', '정읍', '지제', '천안아산' ];
   var code= [ '0514', '0036',    '0507',      '0037', '0010', '0015',  '0552', '0041', '0020','0551', '0508',  '0297', '0509',        '0030', '0033','0553', '0502' ];

   var ref_idx = ref.indexOf( p_region );
   if( ref_idx > 0 )
      return code[ref_idx];
   return 'err';
}

function messageHandler(message, sender, sendResponse)
{
   if (message.command) {

      // **************************************************
      // 정보값 세팅 요청시
      // 세팅 하고나서 로그인 자동 대기모드로 진입시킨다.      
      // **************************************************
      if( message.command == 'set_config') {
         log(message);
         
         config = JSON.parse(message.config);

         log(config);
         srt_id = config['id'].trim();
         srt_pwd = config['password'].trim();

         year = config['year'];
         month= config['month'];
         day= config['day'];

         hour= config['hour'];
         min= config['min'];
         sec= config['sec'];

         srt_auto = config['auto'];         
         wait_time( year, month, day, hour, min, sec );
         sendResponse();
      }

      // **************************************************
      // 예약페이지 document가 ready done인지 확인하는 메시지
      // **************************************************
      if( message.command == 'srt_check_document_ready' ) {
         try{
            var res = ScreenContentFrame.document.readyState === 'complete' ? 'true' : 'false';
         } catch(e){}
         
         log('check document ready');
         
         chrome.runtime.sendMessage( {command:'srt_response_document_ready', ready:res}, function(){} );         
         sendResponse();
      }

      // **************************************************
      // 현재 URI가 예약페이지 인지 확인하는 메시지
      // **************************************************
      if( message.command == 'srt_check_uri' ) {
         var res = location.href.indexOf('selectMainFrame.do') > 0 ? 'true' : 'false'                  
         chrome.runtime.sendMessage( {command:'srt_response_check_uri', data:res}, function(){} );
         sendResponse();
      }


      // **************************************************
      // 즉시예약 탭으로 이동시키는 메시지
      // **************************************************
      if( message.command == 'srt_move_reserve_tab' ){
         log('reserve tab move')

         if( ScreenContentFrame.window.location.href.indexOf('selectBtReserveForm.do') < 0 ) {
            ScreenContentFrame.document.querySelectorAll('body > main > div > div > ul > li:nth-child(2) > a')[0].click();
         }

         try{
            var res = ScreenContentFrame.document.readyState === 'complete' ? 'true' : 'false';
         } catch(e){}
         
         log('check document ready');

         chrome.runtime.sendMessage( {command:'srt_response_move_reserve_tab'}, function(){} );
         chrome.runtime.sendMessage( {command:'srt_response_document_ready', ready:res}, function(){} );
         sendResponse();
      }

      // **************************************************
      // 예약 매크로 메시지
      // **************************************************
      if( message.command == 'srt_reserve' ) {
         //log( message.person_info);
         //log( message.train_info);

         person_info = message.person_info;
         train_info = message.train_info;
         

         if( train_info['depature'] == '' || train_info['arrival'] == '' || train_info['trainNo'] == '' || train_info['date'] == '' )
         {
            log('Exception : train information is empty!!');
            sendResponse();
            return;
         } 

         if( person_info['adult'] == 0 && person_info['child'] == 0 && person_info['weakHeavy'] == 0 && person_info['weakLight'] == 0 && person_info['senior'] == 0 ) 
         {
            log('Exception : person information is empty!!');
            sendResponse();
            return ;
         }         
         
         // 어른
         ScreenContentFrame.document.getElementsByName('txtPsgFlg_1')[0].value=person_info['adult'];

         // 어린이
         ScreenContentFrame.document.getElementsByName('txtPsgFlg_2')[0].value=person_info['child'];

         // 장애중증
         ScreenContentFrame.document.getElementsByName('txtPsgFlg_3')[0].value=person_info['weakHeavy'];

         // 장애경증
         ScreenContentFrame.document.getElementsByName('txtPsgFlg_4')[0].value=person_info['weakLight'];

         // 만 65세이상
         ScreenContentFrame.document.getElementsByName('txtPsgFlg_5')[0].value=person_info['senior'];

         // 6세미만
         ScreenContentFrame.document.getElementsByName('txtPsgFlg_6')[0].value=person_info['baby'];

         // 출발역
         ScreenContentFrame.document.getElementsByName('dptRsStnCd')[0].value=convertCode( train_info['depature'].trim() ) ;

         // 도착역
         ScreenContentFrame.document.getElementsByName('arvRsStnCd')[0].value=convertCode( train_info['arrival'].trim()  ) ;

         // 출발일
         ScreenContentFrame.document.getElementsByName('selGoDay1_1')[0].value=train_info['date'].trim();
         
         // 열차번호 모드전환
         if( ScreenContentFrame.document.getElementById('radTrainNo3').checked == false ) {
            ScreenContentFrame.document.getElementById('radTrainNo3').click();
         }
         // 열차번호 입력
         ScreenContentFrame.document.getElementsByName('txtTrainNo1_1')[0].value=train_info['trainNo'].trim();

         // 예약하기 버튼 클릭
         ScreenContentFrame.document.querySelectorAll('#tab1 > div.srt-tab-footer.srt-text-center.clearfix > a')[0].click();         
                  
         // background에 메시지 전달
         // 다음 예매건에 대해 처리하기 위해 보내는 response
         setTimeout( function(){
            chrome.runtime.sendMessage( {command:'srt_response_srt_reserve'}, function(){} );
         },500);
         sendResponse();
      }      

      // **************************************************
      // 예약 완료 메시지
      // **************************************************
      if( message.command == 'srt_reserve_done' ) {
         sendResponse();
      }

      return true;
    }
}

try{
   // 이 코드는 예매창이 아닌 입구 페이지에서만 동작한다.
   // 코드를 공용으로 로드하므로, 예외처리를 통해 ignore하도록 한다.
   document.querySelectorAll('#section > div > div.top > a > strong')[0].style.fontSize='18px';
   document.querySelectorAll('#section > div > div.top > a > strong ')[0].innerHTML="<div>자동 로그인 대기중</div>";
   
}catch(e) { 
   log( 'error2' , e )
}

// ========================================================================================
// Message Listener
// ========================================================================================
if( typeof(IS_INITED) == 'undefined' ){
   chrome.runtime.onMessage.addListener( messageHandler );   
   IS_INITED = true;   
}

// ========================================================================================
// 초기 호출 끝.
// ========================================================================================


// ========================================================================================
// 사이트 이동 함수( submit )
// ========================================================================================
function jump(a,b,e,d)
{
   // jump를 위한 flow를 수행한다.
   d='post';
   var c=document.createElement('form');
   c.setAttribute('method',d);
   c.setAttribute('action',a);
   c.setAttribute('target',e);
   for(var f in b)
      a=document.createElement('input'),a.setAttribute('type','hidden'),a.setAttribute('name',f),a.setAttribute('value',b[f]),c.appendChild(a);document.body.appendChild(c);
   c.submit();return!1   
}

// ========================================================================================
// 예약페이지 이동 함수
// ========================================================================================
function goReservePage()
{
   jump( uri,
   { 
      'referer':    'etk.srail.kr', 
      'keyValid':   'true', 
      'srchDvNm':    srt_id,  
      'hmpgPwdCphd': srt_pwd,
      'replace':    'https://etk.srail.kr/hpg/hbt/06/selectMainFrame.do',
      'pwdDvCd':    3
   },'_parent');
};

// ========================================================================================
// 예약대기 확인용 blink 함수
// ========================================================================================
var blink = function()
{
   try{
      blink_val = !blink_val;
      if( blink_val )
         $('#section > div > div.top > a > strong ').html( '<div>자동 로그인 대기중</div>' );
      else
         $('#section > div > div.top > a > strong ').html( '<br/>' );   
   } catch(e) {
      // nothing todo
   }
   
}

// ========================================================================================
// 지정날짜 , 시간까지 대기하는 함수
// ========================================================================================
function wait_time( p_year, p_month, p_day, p_hour, p_min, p_sec )
{
   var now = new Date();
   var year = parseInt( now.getFullYear() )
   var month= parseInt( now.getMonth()+1 )
   var day  = parseInt( now.getDate() )
   var hour = parseInt( now.getHours() )
   var min  = parseInt( now.getMinutes() )
   var sec  = parseInt( now.getSeconds() );   

   if( blink_enabled == false ) {
      setInterval( blink, BLINK_INTERVAL_MS );
      blink_enabled = true;
   }

   var loop = function()
   {      
      var info = '<div>현재시간 : ' + year+'년 ' + month + '월 ' + day + '일 ' + hour+'시 ' + min + '분 ' + sec + '초' + '</div>';
          info+= '<div>예정시간 : ' + p_year+'년 ' + p_month + '월 ' + p_day + '일 ' + p_hour+'시 ' + p_min + '분 ' + p_sec + '초' + '</div>';
      //$('#section > div > div.top > a > span').html( info );
      try {
         //document.querySelectorAll('#section > div > div.top > a > strong ')[0].innerHTML=info;
         document.querySelectorAll('#section > div > div.top > a > span')[0].innerHTML=info;
      } catch(e) {
         log( 'error3', e );
      }
      
      setTimeout( function(){ wait_time(p_year, p_month, p_day, p_hour, p_min, p_sec ) }, REFRESH_INTERAVAL_MS );
   }

   var p_sum = parseInt(p_hour)*60*60;
   p_sum += parseInt(p_min)*60;
   p_sum += parseInt(p_sec);

   var sum = parseInt(hour)*60*60;
   sum += parseInt(min)*60;
   sum += parseInt(sec);    

   if( p_year < year || p_year==year && p_month < month || p_year==year && p_month == month && p_day < day ) {
      goReservePage();
   } 
   else 
   {
      if( p_year == year && p_month == month && p_day == day && p_sum  <= sum ) {
         goReservePage();
      } 
      else {
         loop();  
      }
   }   
}








// ==================================================================================================
// 나중에 쓸지 몰라서 남겨둠
// ==================================================================================================
/*
function _sendRequest(url)
{
   // 1. Script 객체 생성
   this.script = document.createElement ("script");

   // 2. Script 객체에 URL 등록, Head에 Script 등록
   this.script.src = url;
   var head = document.getElementsByTagName("head").item(0);

   head.appendChild(this.script);
   return true;
};

function _setCookie(cName, cValue) {
   $.cookie(cName, cValue, {expires: 1, path:'/'});
};

window.NetFunnel={};
NetFunnel.gControl={};
NetFunnel.gControl._showResult = function(){
   value ="";
   var idx1 = NetFunnel.gControl.result.indexOf("key=")+4;
   var idx2 = NetFunnel.gControl.result.indexOf("&");
   _setCookie("NetFunnel_ID",NetFunnel.gControl.result);
};
_sendRequest( "https://nf.letskorail.com/ts.wseq?opcode=5101&nfid=0&prefix=NetFunnel.gRtype=5101;&sid=service_1&aid=act_11&js=true&1671795371240=");

// ===================================================================
// 초기 호출
// ===================================================================
//alert( '자동로그인을 위해서 아이디 비번을 입력하세요' );
//var srt_id = prompt('SRT ID를 입력하세요',        '').trim();
//var srt_pwd = prompt('SRT 비밀번호를 입력하세요', '').trim();


*/