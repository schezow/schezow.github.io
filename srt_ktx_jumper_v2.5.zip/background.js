// ========================================================================================
// Chrome Extension APP 내부 메시지 핸들러
// ========================================================================================
SRT_RESERVE_INFO = '';
SRT_PERSON_INFO = '';
RESERVE_TAB = 0;
RESERVE_LIST_IDX = 0;
RESERVE_AUTO_FLAG = false;
DEBUG_BACKGROUND = true;

// ------------------------------------------------------
// Log함수
// ------------------------------------------------------
function log( ...p_msg )
{
   if( DEBUG_BACKGROUND ) {
      console.log( p_msg );
   }
}

// ------------------------------------------------------
// Filtering Rule Listener
// ------------------------------------------------------
chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(function (m) {
   log('match:', m);
});


// ------------------------------------------------------
// Tab이 업데이트 될떄마다 콜백을 통해 호출받는다.
// ------------------------------------------------------
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
   //code in here will run every time a user goes onto a new tab, so you can insert your scripts into every new tab
   log('debug : ',changeInfo, tab);

   // document 상태가 complete가 되면
   if( changeInfo.status == 'complete' ) {
      // =================================================
      // SRT Re-injection when logged to Reservation Page
      // =================================================   
      if( tab.url.indexOf('selectMainFrame.do') > 0 ) {
         setTimeout( function(){
            log( changeInfo.status, tab.id, tab.url, tab );
            RESERVE_TAB = tab;
            chrome.scripting.executeScript(
            {
               target: { tabId: tab.id /*allFrames: true */ },
               files : ['srt_hack.js']
            },()=>{   
               chrome.tabs.sendMessage( tab.id, {command: "srt_move_reserve_tab", tabInfo:tab.id}, function(res){} );            
            });
         }, 1000);
      }

      // =================================================
      // KTX Re-injection when logged to Reservation Page
      // =================================================
      // todo
   }
}); 

// ------------------------------------------------------
// Message Handler
// ------------------------------------------------------
chrome.runtime.onMessage.addListener(
   (request, sender, sendResponse) => {      
      log(request);

      // *******************************************
      // SRT Auto Reservation List
      // *******************************************
      if( request.command == 'set_reserve_info' ){
         try{
            SRT_RESERVE_INFO = JSON.parse(request.data);            
            RESERVE_AUTO_FLAG = request.auto=='true'? true:false;            
         } catch {
            SRT_RESERVE_INFO = [ {"depature":"","arrival":"","date":"","trainNo":""},                                 
                                 {"depature":"","arrival":"","date":"","trainNo":""} ];
         }
         
         sendResponse();
      }

      // *******************************************
      // SRT Person List
      // *******************************************
      if( request.command == 'set_person_info' ){         
         try{
            SRT_PERSON_INFO = JSON.parse(request.data);            
         } catch (e) {            
            SRT_PERSON_INFO = {"adult":1,   "child":0,   "baby":0,   "weakHeavy":0,   "weakLight":0,   "senior":0};
         }         
         sendResponse();
      }

      // *******************************************
      // SRT Check Is Document Ready
      // *******************************************
      if( request.command == 'srt_response_document_ready' ) {         
         if( request.ready == 'true' ) {            
            if( RESERVE_AUTO_FLAG == true ) {
               RESERVE_LIST_IDX = 0;
               if( RESERVE_LIST_IDX == 0 ) {
                  chrome.tabs.sendMessage( RESERVE_TAB.id, {type:'first', command: "srt_reserve", train_info:SRT_RESERVE_INFO[RESERVE_LIST_IDX++], person_info:SRT_PERSON_INFO}, function(res){} );
                  sendResponse();
               } else {
                  log( 'RESERVE LIST is already used. ');
               }
            } else {
               log( 'RESERVE_AUTO_FLAG is false' )
            }
         } else {            
            setTimeout( function(){
               chrome.tabs.sendMessage( RESERVE_TAB.id, {command: "srt_check_document_ready" }, function(res){} );
               sendResponse();
            }, 2000);            
         }
      }

      // *******************************************
      // SRT Response of URI is valid
      // *******************************************
      if( request.command == 'srt_response_check_uri' ) {
         
         if( request.data == 'true' || request.data == true )
         {            
            if( RESERVE_AUTO_FLAG == true ) {
               chrome.tabs.sendMessage( RESERVE_TAB.id, {command: "srt_move_reserve_tab"}, function(res){} );   
               sendResponse();
            }            
         } else {
            chrome.tabs.sendMessage( RESERVE_TAB.id, {command: "srt_check_uri"}, function(res){} );
            sendResponse();
         }         
      }

      // *******************************************
      // SRT Response of Moved to reserve tab
      // *******************************************
      if( request.command == 'srt_response_move_reserve_tab' ) {         
         /*
         setTimeout( function(){
            chrome.tabs.sendMessage( RESERVE_TAB.id, {command: "srt_check_document_ready"}, function(res){} );
         },3000);
         */
         sendResponse();
      }

      // *******************************************
      // SRT Response of Auto Reservation
      // *******************************************
      if( request.command == 'srt_response_srt_reserve' ) {
         
         if( RESERVE_LIST_IDX < SRT_RESERVE_INFO.length )             
         {            
            // Move Next Train revervation list
            setTimeout( function(){            
               chrome.tabs.sendMessage( RESERVE_TAB.id, {command: "srt_reserve", train_info:SRT_RESERVE_INFO[RESERVE_LIST_IDX++], person_info:SRT_PERSON_INFO}, function(res){} );
               sendResponse();
            }, 1000)            
            
         } else {
            // Stop action and send message "DONE"
            setTimeout( function(){
               RESERVE_LIST_IDX = 0;
               chrome.tabs.sendMessage( RESERVE_TAB.id, {command: "srt_reserve_done"}, function(res){} );
               sendResponse();
            }, 1000);            
         }         
      }
      return true;
   }
);


/*
var log = function(text)
{
   try{
      chrome.extension.getBackgroundPage().console.log(text);
      console.log( '[ background ] : ' + text);
   } catch{

   }   
}
*/