// ========================================================================================
// JSON Template
// ========================================================================================
var person_template ='{"adult":1,   "child":0,   "baby":0,   "weakHeavy":0,   "weakLight":0,   "senior":0}';
var srt_template = '[\n\
{"depature":"동탄","arrival":"부산","date":"20230123","trainNo":"337"},\n\
{"depature":"","arrival":"","date":"","trainNo":""},\n\
{"depature":"","arrival":"","date":"","trainNo":""},\n\
{"depature":"","arrival":"","date":"","trainNo":""}    ]';

var ktx_template = '[\n\
{"depature":"","arrival":"","date":"","trainNo":""},\n\
{"depature":"","arrival":"","date":"","trainNo":""},\n\
{"depature":"","arrival":"","date":"","trainNo":""},\n\
{"depature":"","arrival":"","date":"","trainNo":""}    ]';

// ========================================================================================
// Helper
// ========================================================================================
function help_srt()
{
	var help='출발지, 도착지는 사이트에 검색시 나오는 명칭 그대로 넣으세요\n\n\
예 : 수서, 동대구, 부산\n\n\
날짜는 다음과 같이 입력하세요\n\
예 : 2023년 1월31일 경우,  20230131\n\n\
기차번호는 다음과 같이 입력하세요\n\
예 : 337열차의 경우, 337'
	alert(help);
}

function help_ktx()
{
	var help='출발지, 도착지는 사이트에 검색시 나오는 명칭 그대로 넣으세요\
\n\n\
예 : 수원, 부산, 울산(통도사)\
\n\n\
날짜는 다음과 같이 입력하세요\
\n\
예 : 1월31일 경우,  0131\
\n\n\
기차번호는 다음과 같이 입력하세요\
\n\
예 : 337열차의 경우, 337'
	alert(help);
}
// ========================================================================================
// Helper done
// ========================================================================================



// ===========================================
// Save Options to Local storage
// ===========================================
function save_options( p_msg )
{
	var now = new Date();
   	var year = parseInt( now.getFullYear() )
   	var month= parseInt( now.getMonth()+1 )
   	var day  = parseInt( now.getDate() )
   	var hour = parseInt( now.getHours() )
   	var min  = parseInt( now.getMinutes() )
   	var sec  = parseInt( now.getSeconds() );

	var p_year = $('#year').val()  == '' ? year : $('#year').val();
	var p_month= $('#month').val() == '' ? month: $('#month').val();
	var p_day  = $('#day').val()   == '' ? day  : $('#day').val();
	var p_hour = $('#hour').val()  == '' ? hour : $('#hour').val();
	var p_min  = $('#min').val()   == '' ? min  : $('#min').val();
	var p_sec  = $('#sec').val()   == '' ? sec  : $('#sec').val();

	var p_srt_auto 		= $('#srt_reserve_info').val() == '' ? srt_template : $('#srt_reserve_info').val();
	var p_ktx_auto 		= $('#ktx_reserve_info').val() == '' ? ktx_template : $('#ktx_reserve_info').val();
	var p_person_info 	= $('#person_info').val() == '' ? person_template : $('#person_info').val();

	var p_srt_auto_reserve = $('#chk_srt_auto').is(':checked') == true ? 'true':'false';
	var p_ktx_auto_reserve = $('#chk_ktx_auto').is(':checked') == true ? 'true':'false';

	save_data = { 
		srt_id  		: $('#srt_id').val(),  	
		srt_password 	: $('#srt_password').val(),
		ktx_id  		: $('#ktx_id').val(),
		ktx_password 	: $('#ktx_password').val(),

		year    : p_year,
		month   : p_month,
		day     : p_day,
		hour    : p_hour,
		min     : p_min,
		sec     : p_sec,

		person_info 		: p_person_info,
		srt_reserve_auto 	: p_srt_auto,
		ktx_reserve_auto 	: p_ktx_auto,

		srt_chk_auto_reserve: p_srt_auto_reserve,
		ktx_chk_auto_reserve: p_ktx_auto_reserve,
	};

	chrome.storage.sync.clear();
	chrome.storage.sync.set({'train_info':JSON.stringify(save_data)}, function () {});

	if( p_msg != '' )
		alert(p_msg);
}

// ===========================================
// KTX hack start callback
// ===========================================
function go_ktx()
{
    var config;
	chrome.tabs.query({ active: true }, function (tabs) {
		let tab = tabs[0];
		chrome.scripting.executeScript(
	    {
			target: { tabId: tab.id },
			files: ['jquery.min.js'],	      
	    },()=>{
    		var now = new Date();
		   	var year = parseInt( now.getFullYear() )
		   	var month= parseInt( now.getMonth()+1 )
		   	var day  = parseInt( now.getDate() )
		   	var hour = parseInt( now.getHours() )
		   	var min  = parseInt( now.getMinutes() )
		   	var sec  = parseInt( now.getSeconds() )

			var p_year = $('#year').val()  == '' ? year : $('#year').val();
			var p_month= $('#month').val() == '' ? month: $('#month').val();
			var p_day  = $('#day').val()   == '' ? day  : $('#day').val();
			var p_hour = $('#hour').val()  == '' ? hour : $('#hour').val();
			var p_min  = $('#min').val()   == '' ? min  : $('#min').val();
			var p_sec  = $('#sec').val()   == '' ? sec  : $('#sec').val();

			config_data = { 
				id      : $('#ktx_id').val(),  
				password: $('#ktx_password').val(),
				year    : p_year,
				month   : p_month,
				day     : p_day,
				hour    : p_hour,
				min     : p_min,
				sec     : p_sec,
			};			
			

			config =JSON.stringify(config_data)			

			chrome.tabs.query({ active: true }, function (tabs) {
			  	let tab = tabs[0];	  	
				  	
			  	chrome.scripting.executeScript(
			    {
					target: { tabId: tab.id },
					files: ['ktx_hack.js']
			    },()=>{
		    		chrome.tabs.sendMessage(tab.id,{config:config, command:'set_config'});		    		
			    });						  
			});				
	    });	  
	});	
}

// ===========================================
// KTX hack start callback
// ===========================================
function go_ktx_now()
{
    var config;
	chrome.tabs.query({ active: true }, function (tabs) {
		let tab = tabs[0];
		chrome.scripting.executeScript(
	    {
			target: { tabId: tab.id },
			files: ['jquery.min.js'],	      
	    },()=>{
    		var now = new Date();
		   	var year = parseInt( now.getFullYear() )
		   	var month= parseInt( now.getMonth()+1 )
		   	var day  = parseInt( now.getDate() )
		   	var hour = parseInt( now.getHours() )
		   	var min  = parseInt( now.getMinutes() )
		   	var sec  = parseInt( now.getSeconds() )

			var p_year = $('#year').val()  == '' ? year : $('#year').val();
			var p_month= $('#month').val() == '' ? month: $('#month').val();
			var p_day  = $('#day').val()   == '' ? day  : $('#day').val();
			var p_hour = $('#hour').val()  == '' ? hour : $('#hour').val();
			var p_min  = $('#min').val()   == '' ? min  : $('#min').val();
			var p_sec  = $('#sec').val()   == '' ? sec  : $('#sec').val();

			p_year = 2000;
			config_data = { 
				id      : $('#ktx_id').val(),  
				password: $('#ktx_password').val(),
				year    : p_year,
				month   : p_month,
				day     : p_day,
				hour    : p_hour,
				min     : p_min,
				sec     : p_sec,
			};			
			

			config =JSON.stringify(config_data)			

			chrome.tabs.query({ active: true }, function (tabs) {
			  	let tab = tabs[0];	  	
				  	
			  	chrome.scripting.executeScript(
			    {
					target: { tabId: tab.id },
					files: ['ktx_hack.js']
			    },()=>{
			    	try{
			    		chrome.tabs.sendMessage(tab.id,{config:config, command:'set_config'});
			    	} catch{
			    		setTimeout( go_ktx_now, 500 );
			    	}
		    		
			    });						  
			});				
	    });	  
	});	
}

// ========================================================================================
// SRT hack start callback
// ========================================================================================
function go_srt()
{
	var config;

	chrome.tabs.query({ active: true }, function (tabs) {
		let tab = tabs[0];
		chrome.scripting.executeScript(
	    {
			target: { tabId: tab.id },
			files: ['jquery.min.js'],	      
	    },()=>{
    		var now = new Date();
		   	var year = parseInt( now.getFullYear() )
		   	var month= parseInt( now.getMonth()+1 )
		   	var day  = parseInt( now.getDate() )
		   	var hour = parseInt( now.getHours() )
		   	var min  = parseInt( now.getMinutes() )
		   	var sec  = parseInt( now.getSeconds() )

			var p_year = $('#year').val()  == '' ? year : $('#year').val();
			var p_month= $('#month').val() == '' ? month: $('#month').val();
			var p_day  = $('#day').val()   == '' ? day  : $('#day').val();
			var p_hour = $('#hour').val()  == '' ? hour : $('#hour').val();
			var p_min  = $('#min').val()   == '' ? min  : $('#min').val();
			var p_sec  = $('#sec').val()   == '' ? sec  : $('#sec').val();

			if( $('#srt_id').val() == '' || $('#srt_password').val() == '' )
			{
				alert('로그인정보 확인하세요.')
				return;
			}

			config_data = { 
				id      : $('#srt_id').val(),  
				password: $('#srt_password').val(),
				year    : p_year,
				month   : p_month,
				day     : p_day,
				hour    : p_hour,
				min     : p_min,
				sec     : p_sec,
			};

			var p_srt_auto_reserve = $('#chk_srt_auto').is(':checked') == true ? 'true':'false';
			var p_ktx_auto_reserve = $('#chk_ktx_auto').is(':checked') == true ? 'true':'false';

			config =JSON.stringify(config_data)
			try{
				chrome.runtime.sendMessage( {command:'set_reserve_info', data:$('#srt_reserve_info').val(), auto:p_srt_auto_reserve } );
				chrome.runtime.sendMessage( {command:'set_person_info',  data:$('#person_info').val()} );			

				chrome.tabs.query({ active: true }, function (tabs) {
				  	let tab = tabs[0];	  	
					  	
				  	chrome.scripting.executeScript(
				    {
				      target: { tabId: tab.id },
				      files: ['srt_hack.js']
				    },()=>{
			    		chrome.tabs.sendMessage(tab.id,{config:config, command:'set_config'});		    		
				    });						  
				});				
			} catch {
				setTimeout( go_srt, 500 );
			}
	    });	  
	});    
}

// ========================================================================================
// SRT_NOW hack start callback
// ========================================================================================
function go_srt_now()
{
	var config;

	chrome.tabs.query({ active: true }, function (tabs) {
		let tab = tabs[0];
		chrome.scripting.executeScript(
	    {
			target: { tabId: tab.id },
			files: ['jquery.min.js'],	      
	    },()=>{
    		var now = new Date();
		   	var year = parseInt( now.getFullYear() )
		   	var month= parseInt( now.getMonth()+1 )
		   	var day  = parseInt( now.getDate() )
		   	var hour = parseInt( now.getHours() )
		   	var min  = parseInt( now.getMinutes() )
		   	var sec  = parseInt( now.getSeconds() )

			var p_year = $('#year').val()  == '' ? year : $('#year').val();
			var p_month= $('#month').val() == '' ? month: $('#month').val();
			var p_day  = $('#day').val()   == '' ? day  : $('#day').val();
			var p_hour = $('#hour').val()  == '' ? hour : $('#hour').val();
			var p_min  = $('#min').val()   == '' ? min  : $('#min').val();
			var p_sec  = $('#sec').val()   == '' ? sec  : $('#sec').val();

			p_year = 2000;

			if( $('#srt_id').val() == '' || $('#srt_password').val() == '' )
			{
				alert('로그인정보 확인하세요.')
				return;
			}

			config_data = { 
				id      : $('#srt_id').val(),  
				password: $('#srt_password').val(),
				year    : p_year,
				month   : p_month,
				day     : p_day,
				hour    : p_hour,
				min     : p_min,
				sec     : p_sec,
				auto	: p_srt_auto_reserve,
			};			

			var p_srt_auto_reserve = $('#chk_srt_auto').is(':checked') == true ? 'true':'false';
			var p_ktx_auto_reserve = $('#chk_ktx_auto').is(':checked') == true ? 'true':'false';

			config =JSON.stringify(config_data)
			try{
				chrome.runtime.sendMessage( {command:'set_reserve_info', data:$('#srt_reserve_info').val(), auto:p_srt_auto_reserve } );
				chrome.runtime.sendMessage( {command:'set_person_info',  data:$('#person_info').val()} );			

				chrome.tabs.query({ active: true }, function (tabs) {
				  	let tab = tabs[0];	  	
					  	
				  	chrome.scripting.executeScript(
				    {
				      target: { tabId: tab.id },
				      files: ['srt_hack.js']
				    },()=>{
			    		chrome.tabs.sendMessage(tab.id,{config:config, command:'set_config'});		    		
				    });						  
				});				
			} catch {
				setTimeout( go_srt_now, 500 );
			}			
	    });	  
	});    
}

// ========================================================================================
// 초기화 함수
// ========================================================================================
function onStart()
{
	try{
		//const wconsole = chrome.extension.getBackgroundPage().console;
		//wconsole.log('app started');
	}catch(e){}

	var load_options = function()
	{
		try{
			chrome.storage.sync.get(['train_info'], function(items) {
			try{
				var options = JSON.parse( items.train_info );
				$('#srt_id').val( options.srt_id );
				$('#srt_password').val( options.srt_password );
                $('#ktx_id').val( options.ktx_id );
                $('#ktx_password').val( options.ktx_password );
				$('#year').val( options.year);
				$('#month').val( options.month);
				$('#day').val( options.day);
				$('#hour').val( options.hour);
				$('#min').val( options.min);
				$('#sec').val( options.sec);		

				$('#srt_reserve_info').val( options.srt_reserve_auto );
				if( options.srt_reserve_auto.length == 0 )
					$('#srt_reserve_info').val( srt_template );

				$('#ktx_reserve_info').val( options.ktx_reserve_auto );
				if( options.ktx_reserve_auto.length == 0 )
					$('#ktx_reserve_info').val( ktx_template );

				$('#person_info').val( options.person_info );
				if( options.person_info.lenght == 0 )
					$('#person_info').val( person_template );

				var p_chk_srt_auto = options.srt_chk_auto_reserve == 'true' ? true:false;
				var p_chk_ktx_auto = options.ktx_chk_auto_reserve == 'true' ? true:false;
				
				$('#chk_srt_auto').prop('checked', p_chk_srt_auto);
				$('#chk_ktx_auto').prop('checked', p_chk_ktx_auto);

			} catch(e){}
		});
		} catch(e)
		{

		}		
	}
	load_options();
	
	$('#go_srt').unbind('click').bind('click', go_srt );
	$('#go_srt_now').unbind('click').bind('click', go_srt_now );
	
	$('#go_ktx').unbind('click').bind('click', go_ktx );
	$('#go_ktx_now').unbind('click').bind('click', go_ktx_now );
	$('#btn_help_srt').unbind('click').bind('click', help_srt );
	$('#btn_help_ktx').unbind('click').bind('click', help_ktx );

	$('#save_options').unbind('click').bind('click', 
		function(){ save_options('옵션이 저장되었습니다.') 
		load_options();
	});
	
}

// ========================================================================================
// Message Handler
// ========================================================================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message.command === "request_srt_train_info") {
		sendResponse($('#srt_reserve_info').val());
	}
});

window.onload = onStart;